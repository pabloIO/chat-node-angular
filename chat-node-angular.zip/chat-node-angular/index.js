var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);


app.use(express.static('public'));
app.use('/bower_components', express.static(__dirname + '/bower_components'));
app.use('/node_modules', express.static(__dirname + '/node_modules'));

app.get('/', function(req, res){
  //send the index.html file for all requests
  res.sendFile(__dirname + '/index.html');

});

io.sockets.on('connection', function(client){
	console.log('Cliente conectado: '+ client);
	client.on('chat message', function(data){
		console.log(data);
		client.broadcast.emit('resp', data);
	});
	
});
var port = process.env.PORT || 8000
http.listen(port);
console.log('Conectado en http://localhost: '+port);