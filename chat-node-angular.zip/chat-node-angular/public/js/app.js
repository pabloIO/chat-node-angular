angular.module('chatApp', [
	'ngRoute',
	'btford.socket-io'
]);