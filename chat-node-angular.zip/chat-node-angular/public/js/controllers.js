app = angular.module('chatApp');
app.controller('ChatCtrl', ['$scope', 'socket', function($scope, socket){
	$scope.chat = [
		{comment: "Hola"},
		{comment: "Como estas?"},
		{comment: "Bine y tu?"},
		{comment: "ahi nomas"},
		{comment: "que bien jodete"},
	];
	$scope.mensaje = {
		comment: ""
	};
	$scope.nuevoMensaje = function(){
		socket.emit('chat message', $scope.mensaje.comment);
		var height = $scope.chat[$scope.chat.length - 1].scrollHeight;
		console.log(height);
		$scope.chat.push({comment: $scope.mensaje.comment});
		$scope.mensaje = {
			comment: ""
		};
	};
	socket.on('resp', function(msg){
		$scope.chat.push({comment: msg});
	});
}]);